"use client";
import React from "react";
import FaultTreeApp from "./FaultTreeApp";

export default function App() {
  return <FaultTreeApp />;
}
